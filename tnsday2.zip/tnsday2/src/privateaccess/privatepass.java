package privateaccess;
public class privatepass
{
	private void display()
	{
		System.out.println("hello world");
	}
public static void main(String[] args)
{
	privatepass a=new privatepass();
	a.display();
}
}