package subpackage;

public class packc {
	public void msg()
	{
		System.out.println("hello c");
	}
}