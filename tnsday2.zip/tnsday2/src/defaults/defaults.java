package defaults;
public class defaults {
	void display()
	{
		System.out.println("shashi");
	}
	public static void main(String[] args)
	{
		defaults a=new defaults();
				a.display();
		
	}

}
