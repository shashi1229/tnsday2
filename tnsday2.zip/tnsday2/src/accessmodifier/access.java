package accessmodifier;
public class access {
int a=30;
public static void main(String[] args) 
{
access obj=new access();
System.out.println(obj.a);
}
}
