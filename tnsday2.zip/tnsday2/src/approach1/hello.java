package approach1;

public class hello 
{
	int a=10;
	static int b=20;
	int display()
	{
		return 10;
	}
		static void display1()
		{
			System.out.println(10);
	}

	public static void main(String[] args) {
		int c=30;
		System.out.println(c);
		hello a1=new hello();
		System.out.println(a1.a);
		System.out.println(hello.b);
		a1.display();
		hello.display1();

	}

}
