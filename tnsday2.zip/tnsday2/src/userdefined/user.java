package userdefined;
	import pack.*;
	import subpackage.*;
	public class user
	{
	public static void main(String[] args) 
	{
		packa a1=new packa();
		packb b1=new packb();
		packc c1=new packc();
		a1.msg();
		b1.msg();
		c1.msg();
	}
	}



