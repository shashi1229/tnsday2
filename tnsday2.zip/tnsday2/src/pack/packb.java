package pack;
public class packb {
	public void msg()
	{
		System.out.println("hello b");
	}
}
