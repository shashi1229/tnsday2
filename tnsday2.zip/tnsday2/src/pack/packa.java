package pack;

public class packa {
	public void msg()
	{
		System.out.println("hello A");
	}

}
