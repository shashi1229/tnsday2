package approach2;

public class B 
{
	public static void main(String[] args) 
	{
		int c=30;
		System.out.println(c);
		A a1=new A();
		System.out.println(a1.a);
		System.out.println(A.b);
		a1.display();
		A.display1();
		
	}
}
